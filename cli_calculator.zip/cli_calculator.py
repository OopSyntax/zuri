def calc_logic():
    operator = input("Input arithmethic sign based on addition, subtraction, divion, multiplication or modulus operation > ")
    total = 0
    if operator == "+":
        total = cli_calculator.firstNumber + cli_calculator.secondNumber
        print(total)
    elif operator == "-":
        total = cli_calculator.firstNumber - cli_calculator.secondNumber
        print(total)
    elif operator == "/":
        total = cli_calculator.firstNumber / cli_calculator.secondNumber
        print(total)
    elif operator == "*":
        total = cli_calculator.firstNumber * cli_calculator.secondNumber
        print(total)
    elif operator == "%":
        total = cli_calculator.firstNumber % cli_calculator.secondNumber
        print(total)
    else:
        print("Invalid arithmatic sign chosen")




def cli_calculator():
    firstNumStr = input("Input your first number > ")

    if firstNumStr.isdigit():
        secondNumberStr = input("Input your second number > ")
        cli_calculator.firstNumber = int(firstNumStr)
        if secondNumberStr.isdigit():
            cli_calculator.secondNumber = int(secondNumberStr)
            calc_logic()
        else:
            print("invalid input")
    else:
        print("this is not an integer")





cli_calculator()
